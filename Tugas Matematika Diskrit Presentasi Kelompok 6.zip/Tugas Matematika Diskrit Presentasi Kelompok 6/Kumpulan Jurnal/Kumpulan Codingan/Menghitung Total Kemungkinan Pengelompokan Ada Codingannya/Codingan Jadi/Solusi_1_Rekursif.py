from functools import lru_cache

def count_groupings(counts):
    # Counts: array yang menunjukkan sisa anggota pada setiap kelompok.
    if all(c == 0 for c in counts):
        return 1
    if any(c < 0 for c in counts):
        return 0

    result = 0
    n = len(counts)
    for i in range(n):
        if counts[i] == 0:
            continue
        for j in range(i+1, n):
            if counts[j] == 0:
                continue
            for k in range(j+1, n):
                if counts[k] == 0:
                    continue
                # Pilih 1 anggota dari tiap kelompok i, j, k.
                next_counts = list(counts)
                next_counts[i] -= 1
                next_counts[j] -= 1
                next_counts[k] -= 1
                ways = counts[i] * counts[j] * counts[k]
                result += ways * count_groupings(tuple(next_counts))
    return result

# Contoh pemanggilan program untuk N=4 kelompok
N = 4
init = (3,) * N
print(count_groupings(init))
