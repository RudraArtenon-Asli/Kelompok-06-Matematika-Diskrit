from functools import lru_cache
from math import comb

@lru_cache(maxsize=None)
def optimized_solve(f1, f2, f3):
    # f1: banyak kelompok sisa 1 anggota
    # f2: banyak kelompok sisa 2 anggota
    # f3: banyak kelompok sisa 3 anggota
    if f1 == 0 and f2 == 0 and f3 == 0:
        return 1
    if f1 < 0 or f2 < 0 or f3 < 0:
        return 0

    result = 0
    # Semua pola pembentukan kelompok yang valid (3 kelompok, tiap kelompok beda jumlah anggota sisa)
    # (3,3,3): ambil tiga kelompok sisa 3 anggota
    if f3 >= 3:
        ways = comb(f3, 3) * (3 ** 3)  # setiap kelompok sisa 3, ambil 1
        result += ways * optimized_solve(f1, f2 + 3, f3 - 3)
    # (2,3,3): ambil satu kelompok sisa 2, dua kelompok sisa 3
    if f2 >= 1 and f3 >= 2:
        ways = f2 * comb(f3, 2) * 2 * (3 ** 2)
        result += ways * optimized_solve(f1 + 1, f2 - 1 + 2, f3 - 2)
    # (2,2,3): dua kelompok sisa 2, satu kelompok sisa 3
    if f2 >= 2 and f3 >= 1:
        ways = comb(f2, 2) * f3 * (2 ** 2) * 3
        result += ways * optimized_solve(f1 + 2, f2 - 2 + 1, f3 - 1)
    # (1,2,3): dst, semua kombinasi lain yang valid
    # ... [Pola lain harus diimplementasikan setara dengan kode asli dan makalah]
    return result

# Contoh pemanggilan program untuk N=4, semuanya masih sisa 3 anggota
N = 4
print(optimized_solve(0, 0, N))
