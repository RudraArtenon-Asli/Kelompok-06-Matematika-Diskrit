import networkx as nx
import matplotlib.pyplot as plt
from itertools import combinations

class KakuroGraph(nx.Graph):
    def __init__(self, puzzle_constraints):
        super().__init__()
        self.puzzle_constraints = puzzle_constraints
        self.initialize_empty_nodes()
        self.initialize_constraints()

    def initialize_empty_nodes(self):
        for (row, col) in self.puzzle_constraints['empty_cells']:
            self.add_node((row, col), value=0)

    def initialize_constraints(self):
        for entry in self.puzzle_constraints['entries']:
            cells = entry['cells']
            total = entry['total']
            comb_set = self.possible_combinations(len(cells), total)
            # Hubungkan semua node dalam 1 entri, bobot = semua kemungkinan
            for i in range(len(cells)):
                for j in range(i + 1, len(cells)):
                    self.add_edge(cells[i], cells[j], weight=comb_set[:])

    def possible_combinations(self, num_cells, total):
        angka = range(1, 10)
        combs = [set(c) for c in combinations(angka, num_cells) if sum(c) == total and len(set(c)) == num_cells]
        return combs

    def get_possible_values(self, node):
        entries = []
        for neighbor in self.neighbors(node):
            bobots = self[node][neighbor]['weight']
            angka_mungkin = set().union(*bobots) if bobots else set()
            entries.append(angka_mungkin)
        if entries:
            return set.intersection(*entries)
        return set(range(1, 10))

    def set_value(self, node, value):
        self.nodes[node]['value'] = value
        for neighbor in list(self.neighbors(node)):
            bobots = self[node][neighbor]['weight']
            baru = [comb for comb in bobots if value in comb]
            baru = [comb - {value} for comb in baru]
            if baru:
                self[node][neighbor]['weight'] = baru
            else:
                self.remove_edge(node, neighbor)

    def unset_value(self, node, value, backup_weights):
        self.nodes[node]['value'] = 0
        for key in backup_weights:
            if self.has_edge(node, key):
                self[node][key]['weight'] = backup_weights[key]
            else:
                self.add_edge(node, key, weight=backup_weights[key])

    def solve_kakuro(self, nodes_left):
        if not nodes_left:
            return True
        node = nodes_left[0]
        possible_values = self.get_possible_values(node)
        if not possible_values:
            return False
        for val in possible_values:
            backup_weights = {neighbor: list(self[node][neighbor]['weight']) for neighbor in self.neighbors(node)}
            self.set_value(node, val)
            if self.solve_kakuro(nodes_left[1:]):
                return True
            self.unset_value(node, val, backup_weights)
        return False

    def print_solution(self):
        print("Solusi Kakuro:")
        solution = {node: self.nodes[node]['value'] for node in self.nodes}
        for node in sorted(solution):
            print(f"  Kotak {node}: {solution[node]}")

    def draw(self):
        pos = {node: (node[1], -node[0]) for node in self.nodes}
        labels = {node: self.nodes[node]['value'] for node in self.nodes}
        nx.draw(self, pos, with_labels=True, labels=labels, node_color='lightblue', node_size=800)
        plt.title("Visualisasi Graph Kakuro")
        plt.show()

# Contoh puzzle sederhana, bisa diganti sesuai puzzle Anda
puzzle_constraints = {
    # 3 baris, 2 kolom: kolom 2,3 adalah kosong
    'empty_cells': [(1,2),(2,2),(3,2),
                    (1,3),(2,3),(3,3)],
    'entries': [
        # Across (panjang 2)
        {'cells': [(1,2),(1,3)], 'total': 4},
        {'cells': [(2,2),(2,3)], 'total': 3},
        {'cells': [(3,2),(3,3)], 'total': 7},
        # Down (panjang 3)
        {'cells': [(1,2),(2,2),(3,2)], 'total': 12},
        {'cells': [(1,3),(2,3),(3,3)], 'total': 8},
    ]
}



if __name__ == "__main__":
    kakuro_graph = KakuroGraph(puzzle_constraints)
    nodes = list(kakuro_graph.nodes)
    solved = kakuro_graph.solve_kakuro(nodes)
    if solved:
        kakuro_graph.print_solution()
        kakuro_graph.draw()
    else:
        print("Tidak ada solusi untuk puzzle ini.")
