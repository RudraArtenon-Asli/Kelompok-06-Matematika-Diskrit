from itertools import combinations

def possible_combinations(self, num_cells, total):
    angka = range(1, 10)
    return [set(c) for c in combinations(angka, num_cells) if sum(c) == total and len(set(c)) == num_cells]
