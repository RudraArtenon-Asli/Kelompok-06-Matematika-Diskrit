import networkx as nx

G = nx.Graph()
