def initialize_empty_nodes(self):
    for (row, col) in self.puzzle_constraints['empty_cells']:
        self.add_node((row, col), value=0)
