def set_value(self, node, value):
    self.nodes[node]['value'] = value
    for neighbor in self.neighbors(node):
        for neighbor2 in self.neighbors(neighbor):
            if neighbor2 == node: continue
            # Update kombinasi yang mungkin
            updated_weights = []
            for comb in self[node][neighbor]['weight']:
                if value in comb:
                    # Buang value dari comb
                    new_comb = set(comb) - {value}
                    if new_comb:
                        updated_weights.append(new_comb)
            self[node][neighbor]['weight'] = updated_weights
        # Hapus edge jika hanya tersisa satu kandidat angka
        if len(self[node][neighbor]['weight']) <= 1:
            self.remove_edge(node, neighbor)
