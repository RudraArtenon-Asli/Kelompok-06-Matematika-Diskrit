# Contoh inisialisasi puzzle sederhana
puzzle_constraints = {
    'empty_cells': [(1,2), (1,3), (2,2), (2,3)],
    'entries': [
        {'cells': [(1,2),(1,3)], 'total': 9},
        {'cells': [(1,2),(2,2)], 'total': 11},
        {'cells': [(1,3),(2,3)], 'total': 4},
        {'cells': [(2,2),(2,3)], 'total': 3},
    ]
}

kakuro_graph = KakuroGraph(puzzle_constraints)
kakuro_graph.initialize_empty_nodes()
kakuro_graph.initialize_constraints()
