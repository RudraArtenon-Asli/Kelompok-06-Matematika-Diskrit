import matplotlib.pyplot as plt

nx.draw(G, with_labels=True)
plt.show()
