def solve_kakuro(self, nodes_left):
    if not nodes_left:
        return True
    node = nodes_left[0]
    possible_values = self.get_possible_values(node)
    if not possible_values:
        return False
    for val in possible_values:
        self.set_value(node, val)
        if self.solve_kakuro(nodes_left[1:]):
            return True
        # Undo assignment jika gagal (backtracking)
        self.set_value(node, 0)
    return False
