def initialize_constraints(self):
    for entry in self.puzzle_constraints['entries']:
        cells = entry['cells']
        total = entry['total']
        comb_set = self.possible_combinations(len(cells), total)
        for i in range(len(cells)):
            for j in range(i+1, len(cells)):
                self.add_edge(cells[i], cells[j], weight=comb_set)
