waktu = kombinasi / 10000000

if (waktu < 1):
    print("it will take less than 1 seconds to guess!")
elif (waktu < 60):
    print("it will take", "{:.1f}".format(waktu), "seconds to guess!")
else:
    waktu /= 60
    if (waktu < 60):
        print("it will take", "{:.1f}".format(waktu), "minutes to guess!")
    else:
        waktu /= 60
        if (waktu < 24):
            print("it will take", "{:.1f}".format(waktu), "hours to guess!")
        else:
            waktu /= 24
            if (waktu < 31):
                print("it will take", "{:.1f}".format(waktu), "days to guess!")
            else:
                waktu /= 31
                if (waktu < 12):
                    print("it will take", "{:.1f}".format(waktu), "months to guess!")
                else:
                    waktu /= 12
                    if (waktu < 1000):
                        print("it will take", "{:.1f}".format(waktu), "years to guess!")
                    else:
                        waktu /= 1000
                        if (waktu < 1000):
                            print("it will take", "{:.1f}".format(waktu), "thousand years to guess!")
                        else:
                            waktu /= 1000
                            if (waktu < 1000):
                                print("it will take", "{:.1f}".format(waktu), "million years to guess!")
                            else:
                                waktu /= 1000
                                if (waktu < 1000):
                                    print("it will take", "{:.1f}".format(waktu), "billion years to guess!")
                                else:
                                    print("it will take" + "\033[93m {}\033[00m".format("forever") + " to guess!")
print("\n")
