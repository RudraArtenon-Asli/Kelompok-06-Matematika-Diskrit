kombinasi = float(pow(R, L))
E = np.round(np.log2(kombinasi))

if (E >= 0 and E <= 35):
    print("Your Password is" + "\033[91m {}\033[00m".format("Very Weak!"))
elif (E >= 36 and E <= 59):
    print("Your Password is" + "\033[91m {}\033[00m".format("Weak!"))
elif (E >= 60 and E <= 119):
    print("Your Password is" + "\033[92m {}\033[00m".format("Strong!"))
elif (E >= 120):
    print("Your Password is" + "\033[92m {}\033[00m".format("Very Strong!"))
else:
    print("\033[91m {}\033[00m".format("error!"))
