import numpy as np
password = input(str("Input password : "))
L = len(password)

hurufKecil = False  
hurufBesar = False  
angka = False 
simbol = False
