for i in range(L):
    if (ord(password[i]) >= 97 and ord(password[i]) <= 122):
        hurufKecil = True
    elif (ord(password[i]) >= 65 and ord(password[i]) <= 90):
        hurufBesar = True
    elif (ord(password[i]) >= 48 and ord(password[i]) <= 57):
        angka = True
    else:
        simbol = True
