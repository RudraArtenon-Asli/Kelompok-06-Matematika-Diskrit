R = 0
if (hurufKecil): R += 26
if (hurufBesar): R += 26
if (angka): R += 10
if (simbol): R += 33
