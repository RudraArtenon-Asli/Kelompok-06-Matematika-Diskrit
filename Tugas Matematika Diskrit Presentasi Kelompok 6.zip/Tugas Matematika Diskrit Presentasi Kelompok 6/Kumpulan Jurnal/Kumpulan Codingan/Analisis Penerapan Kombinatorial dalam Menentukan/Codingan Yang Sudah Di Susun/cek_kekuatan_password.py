import numpy as np

password = input(str("Masukkan password: "))
L = len(password)

hurufKecil = False
hurufBesar = False
angka = False
simbol = False

for i in range(L):
    if (ord(password[i]) >= 97 and ord(password[i]) <= 122):
        hurufKecil = True
    elif (ord(password[i]) >= 65 and ord(password[i]) <= 90):
        hurufBesar = True
    elif (ord(password[i]) >= 48 and ord(password[i]) <= 57):
        angka = True
    else:
        simbol = True

R = 0
if (hurufKecil): R += 26
if (hurufBesar): R += 26
if (angka): R += 10
if (simbol): R += 33

kombinasi = float(pow(R, L))
E = np.round(np.log2(kombinasi))

if (E >= 0 and E <= 35):
    print("Password Anda" + "\033[91m {}\033[00m".format(" sangat lemah!"))
elif (E >= 36 and E <= 59):
    print("Password Anda" + "\033[91m {}\033[00m".format(" lemah!"))
elif (E >= 60 and E <= 119):
    print("Password Anda" + "\033[92m {}\033[00m".format(" kuat!"))
elif (E >= 120):
    print("Password Anda" + "\033[92m {}\033[00m".format(" sangat kuat!"))
else:
    print("\033[91m {}\033[00m".format("Terjadi kesalahan!"))

waktu = kombinasi / 10000000  # diasumsikan 10 juta tebakan per detik
if (waktu < 1):
    print("Password Anda bisa ditebak dalam kurang dari 1 detik!")
elif (waktu < 60):
    print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "detik!")
else:
    waktu /= 60
    if (waktu < 60):
        print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "menit!")
    else:
        waktu /= 60
        if (waktu < 24):
            print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "jam!")
        else:
            waktu /= 24
            if (waktu < 31):
                print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "hari!")
            else:
                waktu /= 31
                if (waktu < 12):
                    print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "bulan!")
                else:
                    waktu /= 12
                    if (waktu < 1000):
                        print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "tahun!")
                    else:
                        waktu /= 1000
                        if (waktu < 1000):
                            print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "ribu tahun!")
                        else:
                            waktu /= 1000
                            if (waktu < 1000):
                                print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "juta tahun!")
                            else:
                                waktu /= 1000
                                if (waktu < 1000):
                                    print("Password Anda bisa ditebak dalam waktu", "{:.1f}".format(waktu), "miliar tahun!")
                                else:
                                    print("Password Anda akan sangat sulit ditebak, mungkin tidak akan pernah bisa ditebak!")

print("\n")
print("Kelompok 6 Matematika Diskrit")